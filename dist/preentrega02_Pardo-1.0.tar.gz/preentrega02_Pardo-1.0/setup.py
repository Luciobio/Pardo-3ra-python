from setuptools import setup

setup(
    name="preentrega02_Pardo",
    version="1.0",
    description="Paquete Preentrega 02",
    author="Luciano Pardo",
    author_email="pardobio@gmail.com",

    packages= ["packages"]
)
